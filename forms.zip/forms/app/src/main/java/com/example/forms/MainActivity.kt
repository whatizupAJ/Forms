package com.example.forms

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var hello: TextView
    private lateinit var resetpass: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val email = intent.getStringExtra(constants.EMAIL)
        val password = intent.getStringExtra(constants.PASSWORD)

        resetpass = findViewById(R.id.resetpass)

        hello = findViewById(R.id.hello)
        hello.text = "Hello $email"

        resetpass.setOnClickListener(object : OnClickListener{
            override fun onClick(v: View?){
                resetpassword()
            }
        })

        Log.d("MainActivity", "$email $password")
    }

    private fun resetpassword(){
        val current_password = intent.getStringExtra(constants.PASSWORD)

        val resetIntent = Intent(this, ResetPassword::class.java)
        resetIntent.putExtra(constants.PASSWORD, current_password)

        startActivity(resetIntent)
    }
}