package com.example.forms

import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.View.OnClickListener
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var name: TextView
    private lateinit var logo: ImageView
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        name = findViewById(R.id.name)
        logo = findViewById(R.id.logo)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        button = findViewById(R.id.button)

        button.setOnClickListener(object: View.OnClickListener{
            override fun onClick(v: View?) {
                Log.d("LoginActivity","Login button clicked")
                login()
            }
        })


    }

    private fun login(){

        val isValidPassword = validate_password()
        if (!isValidPassword) {
            Toast.makeText(this, "Password should be greater than 6 characters", Toast.LENGTH_SHORT).show()
            return
        }

        val user_email = email.text.toString()
        val user_password = password.text.toString()
        Log.d("EmailInput", "$user_email $user_password")

        val mainIntent = Intent(this, MainActivity::class.java)
        mainIntent.putExtra(constants.EMAIL, user_email)
        mainIntent.putExtra(constants.PASSWORD, user_password)
        startActivity(mainIntent)
        finish()
        }

    private fun validate_password(): Boolean{
        val user_password = password.text.toString()
        return user_password.length > 6
    }
    }



