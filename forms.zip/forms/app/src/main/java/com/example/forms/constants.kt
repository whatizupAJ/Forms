package com.example.forms

object constants {
    const val EMAIL = "email"
    const val PASSWORD = "password"

}