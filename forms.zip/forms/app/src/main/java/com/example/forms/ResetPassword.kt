package com.example.forms

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class ResetPassword: AppCompatActivity() {
    private lateinit var currentpw: EditText
    private lateinit var resetbutton: Button

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_password_reset)

        currentpw = findViewById(R.id.currentpw)
        resetbutton  = findViewById(R.id.resetbutton)

        val current_password = intent.getStringExtra(constants.PASSWORD)

        currentpw.setText(current_password)

        resetbutton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                finish()
            }
        })

    }
}